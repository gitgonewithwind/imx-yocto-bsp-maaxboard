/*
 * Copyright 2014 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 *
 */

#ifndef __ASM_ARCH_IMX_REGS_H__
#define __ASM_ARCH_IMX_REGS_H__

#define I2C_QUIRK_REG	/* enable 8-bit driver */

#endif /* __ASM_ARCH_IMX_REGS_H__ */
